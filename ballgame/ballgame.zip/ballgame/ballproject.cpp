// qiu_qiu.cpp : �����棨�����а�
#define _CRT_SECURE_NO_WARNINGS

#include <graphics.h>
#include <cmath>
#include <algorithm>
#include <vector>
#include <ctime>
#include <stdio.h>
#include <iostream>
#include <tchar.h>
#include <conio.h>
#include <windows.h>
#include <mmsystem.h>
#include <string.h>
#include <stdlib.h>
#include <fstream>      // �������ļ����������
#include <sstream>      // �������ַ�������������

#pragma comment (lib,"winmm.lib")
#pragma comment(lib, "MSIMG32.LIB")

COLORREF color_coco = RGB(190, 40, 220);
COLORREF color_yp = RGB(138, 43, 226);
int view_width = 1200;
int view_height = 800;
const int VIEW_WIDTH = 1200;
const int VIEW_HEIGHT = 800;
const int BALL_COUNT = 20;
const int FOOD_COUNT = 90;
const int TARGET_FPS = 144;

// ==================== ���а�ȫ�ֱ��� ====================
const int MAX_LEADERBOARD_ENTRIES = 10;
std::vector<int> g_leaderboardScores;   // �������еķ���

// ==================== ԭ���岿�� ====================
struct Ball {
    int x;    // x����
    int y;    // y����
    int r;    // �뾶
    int vx;   // x�����ٶ�
    int vy;   // y�����ٶ�
    COLORREF color; // С����ɫ
};

const int BALL_COUNT_TOTAL = 30;  //С������
std::vector<Ball> g_balls;
bool g_balls_inited = false;

bool is_target_area(int x, int y) {
    return (x < 300 || x > 900 || y < 100 || y > 650);
}

void init_balls(std::vector<Ball>& balls) {
    srand((unsigned int)time(NULL));

    for (int a = 0; a < BALL_COUNT_TOTAL; a++) {
        Ball ball;

        do {
            ball.x = rand() % 1200;
            ball.y = rand() % 800;
        } while (!is_target_area(ball.x, ball.y));

        ball.r = rand() % 10 + 10;
        ball.vx = rand() % 10 - 5;
        if (ball.vx == 0) ball.vx = 1;
        ball.vy = rand() % 10 - 5;
        if (ball.vy == 0) ball.vy = 1;
        ball.color = RGB(rand() % 256, rand() % 256, rand() % 256);

        balls.push_back(ball);
    }
}

void update_balls(std::vector<Ball>& balls) {
    for (auto& ball : balls) {
        int oldX = ball.x;
        int oldY = ball.y;

        ball.x += ball.vx;
        ball.y += ball.vy;

        if (ball.x + ball.r >= 300 && ball.x - ball.r < 300) {
            ball.x = 300 - ball.r - 1;
            ball.vx = -ball.vx;
        }
        else if (ball.x - ball.r <= 900 && ball.x + ball.r > 900) {
            ball.x = 900 + ball.r + 1;
            ball.vx = -ball.vx;
        }

        if (ball.y + ball.r >= 100 && ball.y - ball.r < 100) {
            ball.y = 100 - ball.r - 1;
            ball.vy = -ball.vy;
        }
        else if (ball.y - ball.r <= 650 && ball.y + ball.r > 650) {
            ball.y = 650 + ball.r + 1;
            ball.vy = -ball.vy;
        }

        if (ball.x - ball.r < 0) {
            ball.x = ball.r;
            ball.vx = -ball.vx;
        }
        if (ball.x + ball.r > 1200) {
            ball.x = 1200 - ball.r;
            ball.vx = -ball.vx;
        }
        if (ball.y - ball.r < 0) {
            ball.y = ball.r;
            ball.vy = -ball.vy;
        }
        if (ball.y + ball.r > 800) {
            ball.y = 800 - ball.r;
            ball.vy = -ball.vy;
        }
    }
}

void draw_scene(const std::vector<Ball>& balls) {
    for (const auto& ball : balls) {
        setfillcolor(ball.color);
        solidcircle(ball.x, ball.y, ball.r);
    }
}

void rings_20() {
    if (!g_balls_inited) {
        init_balls(g_balls);
        g_balls_inited = true;
    }
    update_balls(g_balls);
    draw_scene(g_balls);
}

void handleLeftButtonDown(int x, int y)
{
    if (y > 30 && y < 90)
    {
        if (x > 220 && x < 260)
        {
            color_coco = RGB(190, 40, 220);
            color_yp = RGB(138, 43, 226);
        }
        else if (x > 430 && x < 470)
        {
            color_coco = RGB(106, 90, 205);
            color_yp = RGB(72, 61, 139);
        }
        else if (x > 640 && x < 680)
        {
            color_coco = RGB(70, 130, 180);
            color_yp = RGB(90, 150, 200);
        }
        else if (x > 850 && x < 890)
        {
            color_coco = RGB(255, 255, 0);
            color_yp = RGB(204, 153, 51);
        }
    }
    else if (y > 240 && y < 300)
    {
        if (x > 220 && x < 260)
        {
            color_coco = RGB(64, 224, 208);
            color_yp = RGB(0, 128, 128);
        }
        else if (x > 430 && x < 470)
        {
            color_coco = RGB(50, 205, 50);
            color_yp = RGB(34, 139, 34);
        }
        else if (x > 640 && x < 680)
        {
            color_coco = RGB(154, 205, 50);
            color_yp = RGB(174, 215, 70);
        }
        else if (x > 850 && x < 890)
        {
            color_coco = RGB(255, 200, 0);
            color_yp = RGB(205, 133, 63);
        }
    }
    else if (y > 450 && y < 510)
    {
        if (x > 220 && x < 260)
        {
            color_coco = RGB(255, 165, 0);
            color_yp = RGB(204, 85, 0);
        }
        else if (x > 430 && x < 470)
        {
            color_coco = RGB(235, 80, 50);
            color_yp = RGB(160, 60, 45);
        }
        else if (x > 640 && x < 680)
        {
            color_coco = RGB(160, 30, 40);
            color_yp = RGB(128, 0, 32);
        }
    }
}

bool draw_rings = false;
int base_radius = 0;
clock_t ring_start = 0;

void rings_effect() {
    if (!draw_rings) return;

    int current_radius = base_radius;
    bool is_black = true;
    ExMessage msg;

    while (current_radius > 0) {
        if (is_black) {
            setfillcolor(RGB(0, 0, 0));
        }
        else {
            setfillcolor(RGB(255, 255, 255));
        }
        solidcircle(1200 / 2, 800 / 2, current_radius);
        is_black = !is_black;
        current_radius -= 20;

        setfillcolor(color_coco);
        solidcircle(1000, 450, 100);
        setfillcolor(RGB(220, 255, 250));
        solidcircle(1000 - 40, 450 - 25, 32);
        solidcircle(1000 + 40, 450 - 25, 32);
        settextcolor(RGB(0, 2, 2));
        outtextxy(900 + 16, 550, _T("Coco"));

        setfillcolor(RGB(0, 2, 2));
        solidcircle(1000 - 40, 450 - 25, 19);
        solidcircle(1000 + 40, 450 - 25, 19);
    }

    if (clock() - ring_start < 20000 && base_radius < 5000) {
        base_radius += 5;
    }
    else {
        draw_rings = false;
        base_radius = 0;
    }
}

float grayProgress = 0.0f;
DWORD startTime = 0;
const int GRADIENT_DURATION = 8000;

void convertToGrayscale(IMAGE* src, IMAGE* dst) {
    if (startTime == 0) {
        startTime = GetTickCount();
    }

    DWORD currentTime = GetTickCount();
    DWORD elapsedTime = currentTime - startTime;
    grayProgress = (elapsedTime < GRADIENT_DURATION) ?
        (float)elapsedTime / GRADIENT_DURATION : 1.0f;

    DWORD* pSrc = GetImageBuffer(src);
    DWORD* pDst = GetImageBuffer(dst);
    int w = src->getwidth();
    int h = src->getheight();

    for (int i = 0; i < w * h; i++) {
        COLORREF c = pSrc[i];
        BYTE r = GetRValue(c);
        BYTE g = GetGValue(c);
        BYTE b = GetBValue(c);

        BYTE targetGray = (BYTE)(0.299 * r + 0.587 * g + 0.114 * b);

        BYTE newR = (BYTE)(r * (1 - grayProgress) + targetGray * grayProgress);
        BYTE newG = (BYTE)(g * (1 - grayProgress) + targetGray * grayProgress);
        BYTE newB = (BYTE)(b * (1 - grayProgress) + targetGray * grayProgress);

        pDst[i] = RGB(newR, newG, newB);
    }
}

bool musicEnabled = true;
int musicVolume = 500;

void InitMusic() {
    mciSendStringA("close mymusic", NULL, 0, NULL);
}

void PlayBackgroundMusic() {
    if (!musicEnabled) return;
    mciSendStringA("open \"meitu\\aigei_com1.mp3\" alias mymusic", NULL, 0, NULL);
    mciSendStringA("play mymusic repeat", NULL, 0, NULL);
}

void StopBackgroundMusic() {
    mciSendStringA("stop mymusic", NULL, 0, NULL);
    mciSendStringA("close mymusic", NULL, 0, NULL);
}

void PauseBackgroundMusic() {
    mciSendStringA("pause mymusic", NULL, 0, NULL);
}

void ResumeBackgroundMusic() {
    if (!musicEnabled) return;
    mciSendStringA("resume mymusic", NULL, 0, NULL);
}

void PlayEatSound() {
    if (!musicEnabled) return;
    Beep(800, 100);
    Beep(1000, 100);
}

void PlayGameOverSound() {
    if (!musicEnabled) return;
    Beep(400, 500);
    Beep(300, 500);
    Beep(200, 500);
}

void PlayButtonSound() {
    if (!musicEnabled) return;
    Beep(600, 50);
}

struct Food {
    float x, y, r;
    COLORREF color;
    int exist;
};

struct AIBall {
    int x, y, r, vx, vy;
    COLORREF color;
};

struct PlayerBall {
    float x, y, r;
    COLORREF color;
    int score;
} player;

std::vector<AIBall> g_aiBalls;
Food g_foods[FOOD_COUNT];
bool g_ai_balls_inited = false;
bool g_game_over = false;
int g_game_score = 0;

void initPlayer() {
    player.x = VIEW_WIDTH / 2.0f;
    player.y = VIEW_HEIGHT / 2.0f;
    player.r = 15.0f;
    player.color = color_coco;
    player.score = 0;
}

bool isTargetArea(int x, int y) {
    return (x < 1600 && x > 0 && y > 0 && y < 1000);
}

void initAIBalls() {
    g_aiBalls.clear();
    srand((unsigned int)time(NULL));
    for (int i = 0; i < BALL_COUNT; i++) {
        AIBall b;
        do {
            b.x = rand() % VIEW_WIDTH;
            b.y = rand() % VIEW_HEIGHT;
        } while (!isTargetArea(b.x, b.y));

        b.r = rand() % 10 + 10;
        b.vx = rand() % 16 - 8;
        if (b.vx == 0) b.vx = rand() % 2 ? 1 : -1;
        b.vy = rand() % 16 - 8;
        if (b.vy == 0) b.vy = rand() % 2 ? 1 : -1;
        b.color = RGB(rand() % 256, rand() % 256, rand() % 256);
        g_aiBalls.push_back(b);
    }
}

int i = 2;

void generateAIBall() {
    if (g_game_over) return;
    AIBall newBall;
    bool valid = false;

    while (!valid) {
        do {
            newBall.x = rand() % VIEW_WIDTH;
            newBall.y = rand() % VIEW_HEIGHT;
        } while (!isTargetArea(newBall.x, newBall.y));

        i = i + 2;
        if (i > 100) {
            i = 2;
        }
        newBall.r = rand() % i + 20;
        newBall.vx = rand() % 12 - 8;
        if (newBall.vx == 0) newBall.vx = rand() % 2 ? 1 : -1;
        newBall.vy = rand() % 12 - 8;
        if (newBall.vy == 0) newBall.vy = rand() % 2 ? 1 : -1;
        newBall.color = RGB(rand() % 256, rand() % 256, rand() % 256);

        float dx = newBall.x - player.x;
        float dy = newBall.y - player.y;
        float dist = sqrt(dx * dx + dy * dy);
        if (dist > newBall.r + player.r + 10) valid = true;
    }
    g_aiBalls.push_back(newBall);
}

void initFoods() {
    srand((unsigned int)time(NULL));
    for (int i = 0; i < FOOD_COUNT; i++) {
        g_foods[i].x = rand() % VIEW_WIDTH;
        g_foods[i].y = rand() % VIEW_HEIGHT;
        g_foods[i].r = 4.0f;
        g_foods[i].color = RGB(rand() % 256, rand() % 256, rand() % 256);
        g_foods[i].exist = 1;
    }
}

void generateFood(int index) {
    if (index < 0 || index >= FOOD_COUNT) return;
    float newX, newY, d;
    do {
        newX = rand() % VIEW_WIDTH;
        newY = rand() % VIEW_HEIGHT;
        d = pow(newX - player.x, 2) + pow(newY - player.y, 2) - pow(g_foods[index].r + player.r, 2);
    } while (d <= 0);

    g_foods[index].x = newX;
    g_foods[index].y = newY;
    g_foods[index].color = RGB(rand() % 256, rand() % 256, rand() % 256);
    g_foods[index].exist = 1;
}

void movePlayerBall() {
    float baseSpeed = 8.0f;
    float speed = baseSpeed;
    if (GetAsyncKeyState(VK_SHIFT) & 0x8000) speed = baseSpeed * 1.5f;

    if (GetAsyncKeyState(VK_UP) & 0x8000 || GetAsyncKeyState('W') & 0x8000) player.y -= speed;
    if (GetAsyncKeyState(VK_DOWN) & 0x8000 || GetAsyncKeyState('S') & 0x8000) player.y += speed;
    if (GetAsyncKeyState(VK_LEFT) & 0x8000 || GetAsyncKeyState('A') & 0x8000) player.x -= speed;
    if (GetAsyncKeyState(VK_RIGHT) & 0x8000 || GetAsyncKeyState('D') & 0x8000) player.x += speed;

    if (player.x - player.r < 0) player.x = player.r;
    if (player.x + player.r > VIEW_WIDTH) player.x = VIEW_WIDTH - player.r;
    if (player.y - player.r < 0) player.y = player.r;
    if (player.y + player.r > VIEW_HEIGHT) player.y = VIEW_HEIGHT - player.r;
}

void updateAIBalls() {
    for (auto& b : g_aiBalls) {
        int oldX = b.x, oldY = b.y;
        b.x += b.vx; b.y += b.vy;

        if (b.x - b.r < 0) { b.x = b.r; b.vx = -b.vx; }
        if (b.x + b.r > VIEW_WIDTH) { b.x = VIEW_WIDTH - b.r; b.vx = -b.vx; }
        if (b.y - b.r < 0) { b.y = b.r; b.vy = -b.vy; }
        if (b.y + b.r > VIEW_HEIGHT) { b.y = VIEW_HEIGHT - b.r; b.vy = -b.vy; }

        if (!isTargetArea(b.x, b.y)) {
            b.x = oldX; b.y = oldY;
            b.vx = -b.vx; b.vy = -b.vy;
        }
    }
}

void eatFood() {
    for (int i = 0; i < FOOD_COUNT; i++) {
        if (g_foods[i].exist == 0) continue;
        float dx = g_foods[i].x - player.x;
        float dy = g_foods[i].y - player.y;
        float dist = sqrt(dx * dx + dy * dy);

        if (dist < player.r + g_foods[i].r) {
            player.r += 0.3f;
            player.score++;
            g_foods[i].exist = 0;
            PlayEatSound();
            generateFood(i);
        }
    }
}

void checkAICollision() {
    int eatenCount = 0;
    bool wasGameOverBefore = g_game_over;   // ��¼֮ǰ��״̬
    for (auto it = g_aiBalls.begin(); it != g_aiBalls.end();) {
        float dx = it->x - player.x;
        float dy = it->y - player.y;
        float dist = sqrt(dx * dx + dy * dy);

        if (dist < player.r + it->r) {
            if (player.r > it->r) {
                player.r += it->r / 8.0f;
                player.score += it->r;
                PlayEatSound();
                it = g_aiBalls.erase(it);
                eatenCount++;
            }
            else {
                g_game_over = true;
                PlayGameOverSound();
                return;
            }
        }
        else ++it;
    }
    // �����Ϸ�ոս������ӷǽ�����Ϊ�����������ӷ��������а�
    if (!wasGameOverBefore && g_game_over) {
        addScoreToLeaderboard(player.score);   // ��������¼����
    }
    for (int i = 0; i < eatenCount; i++) generateAIBall();
}

void drawPlayerBall() {
    setfillcolor(player.color);
    solidcircle((int)player.x, (int)player.y, (int)player.r);
}

void drawAIBalls() {
    for (const auto& b : g_aiBalls) {
        setfillcolor(b.color);
        solidcircle(b.x, b.y, b.r);
    }
}

void drawFoods() {
    for (int i = 0; i < FOOD_COUNT; i++) {
        if (g_foods[i].exist) {
            setfillcolor(g_foods[i].color);
            solidcircle((int)g_foods[i].x, (int)g_foods[i].y, (int)g_foods[i].r);
        }
    }
}

void drawGameUI() {
    settextcolor(RGB(255, 0, 0));
    settextstyle(30, 0, _T("΢���ź�"));
    TCHAR scoreStr[50], sizeStr[50], aiCountStr[50];
    wsprintf(scoreStr, _T("������%d"), player.score);
    wsprintf(sizeStr, _T("��С��%.0f"), player.r);
    wsprintf(aiCountStr, _T("ʣ��AI��%d"), g_aiBalls.size());
    outtextxy(10, 12, scoreStr);
    outtextxy(10, 52, sizeStr);
    outtextxy(10, 92, aiCountStr);

    settextcolor(RGB(100, 100, 100));
    settextstyle(20, 0, _T("΢���ź�"));
    outtextxy(10, 140, _T("��סShift����"));
}

void drawGameOver() {
    settextcolor(RGB(255, 0, 0));
    settextstyle(48, 0, _T("΢���ź�"));
    outtextxy(VIEW_WIDTH / 2 - 100, VIEW_HEIGHT / 2 - 50, _T("��Ϸ����"));

    TCHAR scoreStr[50];
    wsprintf(scoreStr, _T("���շ�����%d"), player.score);
    settextstyle(36, 0, _T("΢���ź�"));
    outtextxy(VIEW_WIDTH / 2 - 100, VIEW_HEIGHT / 2 + 20, scoreStr);

    settextstyle(24, 0, _T("΢���ź�"));
    outtextxy(VIEW_WIDTH / 2 - 80, VIEW_HEIGHT / 2 + 80, _T("���ո�����ز˵�"));
}

void resetGame() {
    initPlayer();
    initAIBalls();
    initFoods();
    g_game_over = false;
}

void drawGridBackground() {
    setlinecolor(RGB(245, 230, 250));
    setlinestyle(PS_DASHDOT, 1);
    for (int x = 0; x <= VIEW_WIDTH; x += 24) line(x, 0, x, VIEW_HEIGHT);
    for (int y = 4; y <= VIEW_HEIGHT; y += 24) line(0, y, VIEW_WIDTH, y);
}

enum GameStateType {
    menu,
    game,
    shop,
    pause,
    pregame,
    leaderboard       // ���������а�״̬
};

enum EyeStateType {
    eye_open,
    eye_wink1,
    eye_wink2
};

enum HoverStateType {
    normal,
    hover1,
    hover2
};

GameStateType current_state = menu;
EyeStateType eye_state = eye_open;
HoverStateType hover_state = normal;

float grayProgressMain = 0.0f;
DWORD startTimeMain = 0;
void resetGradient() { startTimeMain = 0; grayProgressMain = 0.0f; }

// ==================== ���а���ʵ�� ====================
void loadLeaderboard() {
    g_leaderboardScores.clear();
    std::ifstream fin("leaderboard.dat", std::ios::binary);
    if (!fin) return;
    int score;
    while (fin.read((char*)&score, sizeof(score))) {
        g_leaderboardScores.push_back(score);
    }
    fin.close();
    // ��������
    std::sort(g_leaderboardScores.begin(), g_leaderboardScores.end(), std::greater<int>());
    // ֻ����ǰ MAX_LEADERBOARD_ENTRIES
    if (g_leaderboardScores.size() > MAX_LEADERBOARD_ENTRIES)
        g_leaderboardScores.resize(MAX_LEADERBOARD_ENTRIES);
}

void saveLeaderboard() {
    std::ofstream fout("leaderboard.dat", std::ios::binary);
    for (int s : g_leaderboardScores) {
        fout.write((char*)&s, sizeof(s));
    }
    fout.close();
}

void addScoreToLeaderboard(int newScore) {
    g_leaderboardScores.push_back(newScore);
    std::sort(g_leaderboardScores.begin(), g_leaderboardScores.end(), std::greater<int>());
    if (g_leaderboardScores.size() > MAX_LEADERBOARD_ENTRIES)
        g_leaderboardScores.resize(MAX_LEADERBOARD_ENTRIES);
    saveLeaderboard();
}

// ==================== main ���� ====================
int main(void)
{
    bool goto_exit = false;
    int map_height = 6000;
    int map_width = 8000;
    float mouse_x = 0.0;
    float mouse_y = 0.0;
    clock_t startime_1 = 0;
    clock_t freamtime_1 = 0;
    clock_t startime = 0;
    clock_t freamtime = 0;
    const clock_t FPS = 1000 / 80;
    int score = 0;
    TCHAR str_score[20] = { 0 };
    int x = 0;
    int y = 0;
    int i = 1;

    initgraph(VIEW_WIDTH, VIEW_HEIGHT, TRUE);
    setbkcolor(RGB(220, 255, 250));
    cleardevice();
    setbkmode(TRANSPARENT);

    ExMessage msg = { 0 };
    IMAGE img_bk_1;
    loadimage(&img_bk_1, _T("meitu\\qiuqiu_bk_1.jpg"), 600, 520);
    IMAGE img_bk_2;
    loadimage(&img_bk_2, _T("meitu\\qiuqiu_bk_2.jpg"), 600, 520);
    IMAGE img_shengchen1;
    IMAGE img_shengchen2;
    loadimage(&img_shengchen1, _T("meitu\\qiuqiu_shengchen_1.jpg"), 1200, 800);
    IMAGE img_gray(600, 520);

    InitMusic();
    PlayBackgroundMusic();
    AllocConsole();
    freopen("CONOUT$", "w", stdout);
    printf("�������ս �������Ż��� + �����Ѽ��� + ���а���\n");

    // ��������ʱ�������а�����
    loadLeaderboard();

    while (!goto_exit) {
        startime = clock();

        BeginBatchDraw();
        cleardevice();

        switch (current_state)
        {
        case menu:
        {
            startTime = 0;
            grayProgress = 0.0f;

            setlinecolor(RGB(245, 230, 250));
            setlinestyle(PS_DASHDOT, 1);
            for (int x = 0; x <= VIEW_WIDTH; x += 24) {
                line(x, 0, x, VIEW_HEIGHT);
            }
            for (int y = 4; y <= VIEW_HEIGHT; y += 24) {
                line(0, y, VIEW_WIDTH, y);
            }

            rings_20();

            putimage(300, 0, &img_bk_2, NOTSRCERASE);
            putimage(300, 0, &img_bk_1, SRCINVERT);

            bool hoverStart = (mouse_x >= 410 && mouse_x <= 790 &&
                mouse_y >= 420 && mouse_y <= 550);
            bool hoverShop = (mouse_x >= 410 && mouse_x <= 790 &&
                mouse_y >= 560 && mouse_y <= 690);
            bool hoverLeader = (mouse_x >= 410 && mouse_x <= 790 &&
                mouse_y >= 700 && mouse_y <= 830);   // �������а�ť����

            // ��ʼ��Ϸ��ť
            if (hoverStart)
                setfillcolor(RGB(100, 240, 220));
            else
                setfillcolor(RGB(64, 224, 208));
            solidroundrect(410, 420, 790, 550, 50, 50);
            settextstyle(64, 36, _T("΢���ź�"));
            settextcolor(RGB(0, 0, 0));
            outtextxy(440, 460, _T("��ʼ��Ϸ"));

            // Ƥ���̳ǰ�ť
            if (hoverShop)
                setfillcolor(RGB(100, 240, 220));
            else
                setfillcolor(RGB(64, 224, 208));
            solidroundrect(410, 560, 790, 690, 50, 50);
            settextstyle(64, 36, _T("΢���ź�"));
            settextcolor(RGB(0, 0, 0));
            outtextxy(440, 590, _T("Ƥ���̳�"));

            // ���а�ť��������
            if (hoverLeader)
                setfillcolor(RGB(100, 240, 220));
            else
                setfillcolor(RGB(64, 224, 208));
            solidroundrect(410, 700, 790, 830, 50, 50);
            settextstyle(64, 36, _T("΢���ź�"));
            settextcolor(RGB(0, 0, 0));
            outtextxy(440, 730, _T("���а�"));

            setfillcolor(color_coco);
            solidcircle(1000, 450, 100);
            setfillcolor(RGB(220, 255, 250));
            solidcircle(1000 - 40, 450 - 25, 32);
            solidcircle(1000 + 40, 450 - 25, 32);
            settextcolor(RGB(70, 80, 120));
            outtextxy(900 + 16, 550, _T("Coco"));

            // ����¼�����
            while (peekmessage(&msg, EX_MOUSE))
            {
                if (msg.message == WM_LBUTTONDOWN)
                {
                    if (msg.x >= 410 && msg.x <= 790 && msg.y >= 420 && msg.y <= 550)
                    {
                        freamtime_1 = clock();
                        current_state = pregame;
                    }
                    else if (msg.x >= 410 && msg.x <= 790 && msg.y >= 560 && msg.y <= 690)
                    {
                        current_state = shop;
                    }
                    else if (msg.x >= 410 && msg.x <= 790 && msg.y >= 700 && msg.y <= 830)
                    {
                        current_state = leaderboard;
                        loadLeaderboard();   // �������а�ʱˢ������
                    }
                    else if (msg.x >= 13 * 24 && msg.x <= 16 * 24 && msg.y >= 10 * 24 && msg.y <= 13 * 24)
                    {
                        eye_state = eye_wink1;
                    }
                    else if (msg.x >= 37 * 24 && msg.x <= 46 * 24 && msg.y >= 14 * 24 && msg.y <= 24 * 24)
                    {
                        eye_state = eye_wink2;
                    }

                    if (msg.x >= 1100 && msg.x <= 1180 && msg.y >= 20 && msg.y <= 60) {
                        PlayButtonSound();
                        musicEnabled = !musicEnabled;
                        if (musicEnabled) ResumeBackgroundMusic();
                        else PauseBackgroundMusic();
                    }
                }
                else if (msg.message == WM_MOUSEMOVE)
                {
                    mouse_x = msg.x;
                    mouse_y = msg.y;

                    if (eye_state == eye_wink1)
                    {
                        if (msg.x <= 12 * 24 || msg.x >= 18 * 24 || msg.y <= 10 * 24 || msg.y >= 13 * 24)
                        {
                            eye_state = eye_open;
                        }
                    }
                    else if (eye_state == eye_wink2)
                    {
                        if (msg.x <= 37 * 24 || msg.x >= 46 * 24 || msg.y <= 14 * 24 || msg.y >= 24 * 24)
                        {
                            eye_state = eye_open;
                        }
                    }

                    if (msg.x <= 790 && msg.x >= 410 && msg.y <= 550 && msg.y >= 420)
                    {
                        hover_state = hover1;
                    }

                    if (msg.x <= 790 && msg.x >= 410 && msg.y <= 690 && msg.y >= 560)
                    {
                        hover_state = hover2;
                    }

                    if (msg.x >= 790 || msg.x <= 410 || msg.y >= 550 || msg.y <= 420)
                    {
                        hover_state = normal;
                    }

                    if (msg.x >= 790 || msg.x <= 410 || msg.y >= 690 || msg.y <= 560)
                    {
                        hover_state = normal;
                    }
                }
            }

            // �۾���������ԭ����ͬ��
            if (eye_state == eye_wink1)
            {
                setfillcolor(RGB(128, 0, 128));
                solidellipse(311, 267, 341, 287);
                solidellipse(361, 267, 391, 287);
                setfillcolor(RGB(0, 2, 2));
                solidcircle(1000 - 40 + (mouse_x - 1000 + 40) / 60, 450 - 25 + (mouse_y - 450 + 25) / 60, 19);
                solidcircle(1000 + 40 + (mouse_x - 1000 - 40) / 60, 450 - 25 + (mouse_y - 450 + 25) / 60, 19);
            }
            else if (eye_state == eye_wink2)
            {
                setfillcolor(color_yp);
                solidcircle(1000 - 40, 450 - 25, 32);
                solidcircle(1000 + 40, 450 - 25, 32);
                setfillcolor(RGB(0, 2, 2));
                solidcircle(327 + (mouse_x - 327) / 70, 278 + (mouse_y - 278) / 70, 6);
                solidcircle(377 + (mouse_x - 377) / 70, 278 + (mouse_y - 278) / 70, 6);
            }
            else if (eye_state == eye_open)
            {
                setfillcolor(RGB(0, 2, 2));
                solidcircle(327 + (mouse_x - 327) / 70, 278 + (mouse_y - 278) / 70, 6);
                solidcircle(377 + (mouse_x - 377) / 70, 278 + (mouse_y - 278) / 70, 6);
                solidcircle(1000 - 40 + (mouse_x - 1000 + 40) / 60, 450 - 25 + (mouse_y - 450 + 25) / 60, 19);
                solidcircle(1000 + 40 + (mouse_x - 1000 - 40) / 60, 450 - 25 + (mouse_y - 450 + 25) / 60, 19);
            }

            // ��ͣЧ������ԭ�����ƣ����������а�ť�������⴦����
            if (hover_state == hover1) {
                setfillcolor(RGB(180, 180, 180));
                solidroundrect(412, 422, 792, 552, 50, 50);
                setfillcolor(RGB(64, 224, 208));
                solidroundrect(410, 420, 790, 550, 50, 50);
                setcolor(RGB(255, 255, 255));
                setlinestyle(PS_SOLID, 2);
                line(415, 420, 785, 420);
                line(410, 425, 410, 545);
                solidroundrect(410, 560, 790, 690, 50, 50);
                settextstyle(64, 36, _T("΢���ź�"));
                settextcolor(RGB(0, 0, 0));
                outtextxy(440, 590, _T("Ƥ���̳�"));
            }
            break;
        }

        case pregame:
        {
            setlinecolor(RGB(195, 195, 200));
            setlinestyle(PS_DASHDOT, 1);
            for (int x = 0; x <= VIEW_WIDTH; x += 24) {
                line(x, 0, x, VIEW_HEIGHT);
            }
            for (int y = 4; y <= VIEW_HEIGHT; y += 24) {
                line(0, y, VIEW_WIDTH, y);
            }

            rings_20();

            convertToGrayscale(&img_bk_1, &img_gray);
            putimage(300, 0, &img_bk_2, NOTSRCERASE);
            putimage(300, 0, &img_gray, SRCINVERT);

            setfillcolor(color_coco);
            solidcircle(1000, 450, 100);
            setfillcolor(RGB(220, 255, 250));
            solidcircle(1000 - 40, 450 - 25, 32);
            solidcircle(1000 + 40, 450 - 25, 32);
            settextcolor(RGB(0, 2, 2));

            setfillcolor(RGB(0, 2, 2));
            solidcircle(327 + (mouse_x - 327) / 70, 278 + (mouse_y - 278) / 70, 6);
            solidcircle(377 + (mouse_x - 377) / 70, 278 + (mouse_y - 278) / 70, 6);
            solidcircle(1000 - 40 + (mouse_x - 1000 + 40) / 60, 450 - 25 + (mouse_y - 450 + 25) / 60, 19);
            solidcircle(1000 + 40 + (mouse_x - 1000 - 40) / 60, 450 - 25 + (mouse_y - 450 + 25) / 60, 19);

            setfillcolor(RGB(230, 230, 240));
            solidroundrect(410, 420, 790, 550, 50, 50);
            settextstyle(64, 36, _T("΢���ź�"));
            settextcolor(RGB(0, 0, 0));
            outtextxy(440, 460, _T("��ʼ��Ϸ"));

            solidroundrect(410, 560, 790, 690, 50, 50);
            settextstyle(64, 36, _T("΢���ź�"));
            settextcolor(RGB(0, 0, 0));
            outtextxy(440, 590, _T("Ƥ���̳�"));

            startime_1 = clock();
            if ((startime_1 - freamtime_1) > 9000) {
                current_state = pause;
                draw_rings = true;
                ring_start = clock();
                base_radius = 0;
            }

            while (peekmessage(&msg, EX_MOUSE))
            {
                if (msg.message == WM_MBUTTONDOWN)
                {
                    current_state = game;
                    resetGame();
                }

                if (msg.message == WM_LBUTTONDOWN) {
                    if (msg.x >= 1100 && msg.x <= 1180 && msg.y >= 20 && msg.y <= 60) {
                        PlayButtonSound();
                        musicEnabled = !musicEnabled;
                        if (musicEnabled) ResumeBackgroundMusic();
                        else PauseBackgroundMusic();
                    }
                }
            }
            break;
        }

        case pause:
        {
            setlinecolor(RGB(195, 195, 200));
            setlinestyle(PS_DASHDOT, 1);
            for (int x = 0; x <= VIEW_WIDTH; x += 24) {
                line(x, 0, x, VIEW_HEIGHT);
            }
            for (int y = 4; y <= VIEW_HEIGHT; y += 24) {
                line(0, y, VIEW_WIDTH, y);
            }

            rings_20();

            convertToGrayscale(&img_bk_1, &img_gray);
            putimage(300, 0, &img_bk_2, NOTSRCERASE);
            putimage(300, 0, &img_gray, SRCINVERT);

            setfillcolor(color_coco);
            solidcircle(1000, 450, 100);
            setfillcolor(RGB(220, 255, 250));
            solidcircle(1000 - 40, 450 - 25, 32);
            solidcircle(1000 + 40, 450 - 25, 32);
            settextcolor(RGB(0, 2, 2));

            setfillcolor(RGB(0, 2, 2));
            solidcircle(327 + (mouse_x - 327) / 70, 278 + (mouse_y - 278) / 70, 6);
            solidcircle(377 + (mouse_x - 377) / 70, 278 + (mouse_y - 278) / 70, 6);
            solidcircle(1000 - 40 + (mouse_x - 1000 + 40) / 60, 450 - 25 + (mouse_y - 450 + 25) / 60, 19);
            solidcircle(1000 + 40 + (mouse_x - 1000 - 40) / 60, 450 - 25 + (mouse_y - 450 + 25) / 60, 19);

            setfillcolor(RGB(230, 230, 240));
            solidroundrect(410, 420, 790, 550, 50, 50);
            settextstyle(64, 36, _T("΢���ź�"));
            settextcolor(RGB(0, 0, 0));
            outtextxy(440, 460, _T("��ʼ��Ϸ"));

            solidroundrect(410, 560, 790, 690, 50, 50);
            settextstyle(64, 36, _T("΢���ź�"));
            settextcolor(RGB(0, 0, 0));
            outtextxy(440, 590, _T("Ƥ���̳�"));

            while (peekmessage(&msg, EX_MOUSE))
            {
                if (msg.message == WM_MBUTTONDOWN)
                {
                    current_state = game;
                    resetGame();
                }

                if (msg.message == WM_LBUTTONDOWN) {
                    if (msg.x >= 1100 && msg.x <= 1180 && msg.y >= 20 && msg.y <= 60) {
                        PlayButtonSound();
                        musicEnabled = !musicEnabled;
                        if (musicEnabled) ResumeBackgroundMusic();
                        else PauseBackgroundMusic();
                    }
                }
            }

            rings_effect();

            startime_1 = clock();
            if ((startime_1 - freamtime_1) > 17000) {
                current_state = game;
                resetGame();
            }
            break;
        }

        case game:
        {
            setlinecolor(RGB(245, 230, 250));
            setlinestyle(PS_DASHDOT, 1);
            for (int x = 0; x <= VIEW_WIDTH; x += 24) {
                line(x, 0, x, VIEW_HEIGHT);
            }
            for (int y = 4; y <= VIEW_HEIGHT; y += 24) {
                line(0, y, VIEW_WIDTH, y);
            }

            if (!g_game_over) {
                drawGridBackground(); movePlayerBall(); updateAIBalls(); eatFood(); checkAICollision();
                drawFoods(); drawAIBalls(); drawPlayerBall(); drawGameUI();
            }
            else {
                drawGridBackground(); drawFoods(); drawAIBalls(); drawGameOver();
            }

            if (GetAsyncKeyState(VK_SPACE) & 0x8000) {
                if (g_game_over) {
                    current_state = menu;
                    resetGame();
                    startTime = 0;
                    grayProgress = 0.0f;
                }
            }
            if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) {
                current_state = menu;
                resetGame();
                startTime = 0;
                grayProgress = 0.0f;
            }

            while (peekmessage(&msg, EX_MOUSE))
            {
                if (msg.message == WM_MBUTTONDOWN)
                {
                    current_state = menu;
                    resetGame();
                    startTime = 0;
                    grayProgress = 0.0f;
                }

                if (msg.message == WM_LBUTTONDOWN) {
                    if (msg.x >= 1100 && msg.x <= 1180 && msg.y >= 20 && msg.y <= 60) {
                        PlayButtonSound();
                        musicEnabled = !musicEnabled;
                        if (musicEnabled) ResumeBackgroundMusic();
                        else PauseBackgroundMusic();
                    }
                }
            }
            break;
        }

        case shop:
        {
            setlinecolor(RGB(245, 230, 250));
            setlinestyle(PS_DASHDOT, 1);
            for (int x = 0; x <= VIEW_WIDTH; x += 24) {
                line(x, 0, x, VIEW_HEIGHT);
            }
            for (int y = 4; y <= VIEW_HEIGHT; y += 24) {
                line(0, y, VIEW_WIDTH, y);
            }
            putimage(0, 0, &img_shengchen1);

            setfillcolor(color_coco);
            solidcircle(1000, 450, 100);
            setfillcolor(RGB(220, 255, 250));
            solidcircle(1000 - 40, 450 - 25, 32);
            solidcircle(1000 + 40, 450 - 25, 32);

            settextcolor(RGB(190, 40, 220));
            settextstyle(40, 20, _T("΢���ź�"));
            outtextxy(230, 40, _T("ԭ��ɫ"));
            settextcolor(RGB(106, 90, 205));
            outtextxy(440, 40, _T("޹�²�ɫ"));
            settextcolor(RGB(70, 130, 180));
            outtextxy(650, 40, _T("����ɫ"));
            settextcolor(RGB(255, 255, 0));
            outtextxy(860, 40, _T("���ʻ�ɫ"));
            settextcolor(RGB(64, 224, 208));
            outtextxy(230, 250, _T("����ɫ"));
            settextcolor(RGB(50, 205, 50));
            outtextxy(440, 250, _T("��ʯ��ɫ"));
            settextcolor(RGB(154, 205, 50));
            outtextxy(650, 250, _T("����ɫ"));
            settextcolor(RGB(255, 200, 0));
            outtextxy(860, 250, _T("�Ȼ�ɫ"));
            settextcolor(RGB(255, 165, 0));
            outtextxy(230, 460, _T("�ٻ�ɫ"));
            settextcolor(RGB(235, 80, 50));
            outtextxy(440, 460, _T("���ɫ"));
            settextcolor(RGB(160, 30, 40));
            outtextxy(650, 460, _T("���ɫ"));

            while (peekmessage(&msg, EX_MOUSE))
            {
                switch (msg.message)
                {
                case WM_MBUTTONDOWN:
                    current_state = menu;
                    startTime = 0;
                    grayProgress = 0.0f;
                    break;
                case WM_MOUSEMOVE:
                    mouse_x = msg.x;
                    mouse_y = msg.y;
                    if (msg.x <= 37 * 24 || msg.x >= 46 * 24 || msg.y <= 14 * 24 || msg.y >= 24 * 24)
                    {
                        eye_state = eye_open;
                    }
                    break;
                case WM_LBUTTONDOWN:
                    if (msg.x >= 37 * 24 && msg.x <= 46 * 24 && msg.y >= 14 * 24 && msg.y <= 24 * 24)
                    {
                        eye_state = eye_wink2;
                    }
                    if (msg.x >= 1100 && msg.x <= 1180 && msg.y >= 20 && msg.y <= 60) {
                        PlayButtonSound();
                        musicEnabled = !musicEnabled;
                        if (musicEnabled) ResumeBackgroundMusic();
                        else PauseBackgroundMusic();
                    }
                    handleLeftButtonDown(msg.x, msg.y);
                    break;
                default:
                    break;
                }
            }

            if (eye_state == eye_wink2)
            {
                setfillcolor(color_yp);
                solidcircle(1000 - 40, 450 - 25, 32);
                solidcircle(1000 + 40, 450 - 25, 32);
            }
            else if (eye_state == eye_open)
            {
                setfillcolor(RGB(0, 2, 2));
                solidcircle(1000 - 40 + (mouse_x - 1000 + 40) / 60, 450 - 25 + (mouse_y - 450 + 25) / 60, 19);
                solidcircle(1000 + 40 + (mouse_x - 1000 - 40) / 60, 450 - 25 + (mouse_y - 450 + 25) / 60, 19);
            }

            settextcolor(color_coco);
            settextstyle(100, 40, _T("΢���ź�"));
            outtextxy(80, 640, _T("���ɫ�Ƶ�һ�����Ըı���ɫ"));
            break;
        }

        // ==================== ���������а���� ====================
        case leaderboard:
        {
            // ��������
            setlinecolor(RGB(245, 230, 250));
            setlinestyle(PS_DASHDOT, 1);
            for (int x = 0; x <= VIEW_WIDTH; x += 24) line(x, 0, x, VIEW_HEIGHT);
            for (int y = 4; y <= VIEW_HEIGHT; y += 24) line(0, y, VIEW_WIDTH, y);

            // ����
            settextcolor(RGB(138, 43, 226));
            settextstyle(64, 36, _T("΢���ź�"));
            outtextxy(450, 40, _T("���а�"));

            // ��ʾǰ10������
            settextstyle(36, 18, _T("΢���ź�"));
            if (g_leaderboardScores.empty()) {
                settextcolor(RGB(100, 100, 100));
                outtextxy(400, 200, _T("���޼�¼"));
            }
            else {
                for (size_t i = 0; i < g_leaderboardScores.size(); i++) {
                    TCHAR str[100];
                    wsprintf(str, _T("�� %d ��: %d"), i + 1, g_leaderboardScores[i]);
                    settextcolor(RGB(50, 50, 50));
                    outtextxy(400, 140 + i * 50, str);
                }
            }

            // ������ʾ
            settextstyle(28, 14, _T("΢���ź�"));
            settextcolor(RGB(100, 100, 100));
            outtextxy(350, 700, _T("������м� �� ESC ���ز˵�"));

            // ����¼�
            while (peekmessage(&msg, EX_MOUSE)) {
                if (msg.message == WM_MBUTTONDOWN) {
                    current_state = menu;
                    startTime = 0;
                    grayProgress = 0.0f;
                }
                if (msg.message == WM_KEYDOWN && msg.vkcode == VK_ESCAPE) {
                    current_state = menu;
                    startTime = 0;
                    grayProgress = 0.0f;
                }
                if (msg.message == WM_LBUTTONDOWN) {
                    if (msg.x >= 1100 && msg.x <= 1180 && msg.y >= 20 && msg.y <= 60) {
                        PlayButtonSound();
                        musicEnabled = !musicEnabled;
                        if (musicEnabled) ResumeBackgroundMusic();
                        else PauseBackgroundMusic();
                    }
                }
            }

            // ���ְ�ť
            {
                bool hoverMusic = (mouse_x >= 1100 && mouse_x <= 1180 &&
                    mouse_y >= 20 && mouse_y <= 60);
                if (hoverMusic) setfillcolor(RGB(230, 230, 240));
                else setfillcolor(RGB(199, 200, 201));
                solidroundrect(1100, 20, 1180, 60, 20, 20);
                settextcolor(color_yp);
                settextstyle(20, 10, _T("΢���ź�"));
                outtextxy(1114, 31, musicEnabled ? _T("���ֿ�") : _T("���ֹ�"));
            }
            break;
        }
        }

        // �������ְ�ť������״̬�Ѱ������˴������ظ����ƣ�
        // �� menu, pregame, pause, game, shop ���ѻ������ְ�ť
        // ���а�״̬��Ҳ�ѻ��ƣ���˲������ӹ�������

        EndBatchDraw();

        freamtime = clock() - startime;
        if (freamtime < FPS) {
            Sleep(FPS - freamtime);
        }
    }

    closegraph();
    return 0;
}